This is a simple guide to get our application working on your machine.

Create a Gradle Project and name it whatever you like in eclipse
Delete any generated main or test files
Import the CSSE375.jar file as an Archive File
Before Importing make sure your Into folder path is <Project Name/src/main/java>
Drag in the new build.gradle file
Import the dependencies from the dependencies folder

You now have a fully running project!

In terms of configuration heres what you need to do

Goto

Window > Preferences > General > Workspace

When here you enable the “Refresh Using native hooks or polling”

